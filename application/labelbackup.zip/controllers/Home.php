<?php
    class Home extends CI_Controller{
        
        function __construct(){
            parent::__construct();
            $this->load->library('session');
            $user_id=$this->session->userdata('admin_id');
            $role = $this->session->userdata('role');
            if(empty($user_id)){
                redirect("Admin");
            }
        }

        public function NavData(){
            $NavData =  array(
                'error'=>''
            );
            return $NavData;
        }

        private function Support($view,$data=[]){
            $NavData = $this->NavData();
            $data = array_merge_recursive($NavData,$data);
            $this->load->view("NavFoot/navbar",$data);
            $this->load->view($view);
            $this->load->view("NavFoot/footer");
        }

        public function index(){
            $view = "User/dashboard";
            $data = array(
                'page' => 'dashboard',
                'type' => '',
                'title' => 'Dashboard',
            );
            $this->Support($view, $data);
            
        }

    }
?>