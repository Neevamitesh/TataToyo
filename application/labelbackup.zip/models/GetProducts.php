<?php
    class GetProducts extends CI_Model{
        function __construct(){
            parent::__construct();
            $this->load->library('session');
            $this->load->database();
            
        }
        public function UploadProduct($data){
            $insert_user_stored_proc = "CALL spproductmaster(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $query = $this->db->query($insert_user_stored_proc, $data);
            mysqli_next_result( $this->db->conn_id );
            return $query->row();
        }
        public function GetAllProducts(){
            $data = array(
                'itype' => 'GetAllProducts',
                'iid' => 0,
                'iCMID' => 0,
                'iproductcode' => '',
                'iproductname' => '',
                'iproductdescriptionone' => '',
                'iproductdescriptiontwo' => '',
                'iproductcategory' => '',
                'iproductprice' => '',
                'iproductstockquantity' => '',
                'iuploadimage' => '',
                'iother1' => '',
                'iother2' => '',
                'iother3' => '',
                'icreatedby' => '',
                'iupdatedflag' => '',
                'irefdate' => '',
                'ifinyear' => '',
                'iupdatedtimestamp' => '',
                'icreatedthrough' => '',
                'iupdatedthrough' => '',
            );
            $stored_proc = "CALL spproductmaster(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $data1 = $this->db->query($stored_proc, $data);
            $this->db->close();
            return $data1;
        }
        public function GetAllConsignee(){
            return $this->db->get_where("consigneemaster", ["isactive" => 1]);
        }
        public function GetProductVariables($PID){
            return $this->db->get_where("productdetail", ["BitStatus" => 1, "PID" => $PID]);
            // mysqli_next_result( $this->db->conn_id );
            // $this->db->close();
            // return $query;
        }
        public function GetProductDetail($PID){
            $data = array(
                'itype' => 'GetAllProductDetail',
                'iid' => $PID,
                'iCMID' => 0,
                'iproductcode' => '',
                'iproductname' => '',
                'iproductdescriptionone' => '',
                'iproductdescriptiontwo' => '',
                'iproductcategory' => '',
                'iproductprice' => '',
                'iproductstockquantity' => '',
                'iuploadimage' => '',
                'iother1' => '',
                'iother2' => '',
                'iother3' => '',
                'icreatedby' => '',
                'iupdatedflag' => '',
                'irefdate' => '',
                'ifinyear' => '',
                'iupdatedtimestamp' => '',
                'icreatedthrough' => '',
                'iupdatedthrough' => '',
            );
            $stored_proc = "CALL spproductmaster(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $query = $this->db->query($stored_proc, $data);
            mysqli_next_result( $this->db->conn_id );
            return $query->row();
        }
        public function AddProductDetail($detail){
            return $this->db->insert_batch("ProductDetail", $detail);
        }
        public function DeleteProduct($CVID){
            $this->db->select("FVID");
            $this->db->from("Color_Variations");
            $this->db->where("CVID", $CVID);
            $ID = $this->db->get()->row();
            $FVID = $ID->FVID;
            
            $this->db->select("FVID");
            $this->db->from("Color_Variations");
            $this->db->where("FVID", $FVID);
            $res = $this->db->get();
            $count = $res->num_rows();

            if($count==1){                
                $this->db->set("BitStatus", 0);
                $this->db->where("FVID", $FVID);
                $this->db->update("Feature_Variations");
            }

            $this->db->set("BitStatus", 0);
            $this->db->where("CVID", $CVID);
            $this->db->update("Product_Attachments");

            $this->db->set("BitStatus", 0);
            $this->db->where("CVID", $CVID);
            return $this->db->update("Color_Variations");

        }
        public function UpdateProduct($CVID, $feat, $col){
            $this->db->select("FVID");
            $this->db->from("Color_Variations");
            $this->db->where("CVID", $CVID);
            $ID = $this->db->get()->row();
            $FVID = $ID->FVID;

            $this->db->select("SID");
            $this->db->from("Feature_Variations");
            $this->db->where("FVID", $FVID);
            $result = $this->db->get()->row();
            $SID = $result->SID;
            
            $this->db->select("FVID");
            $this->db->from("Color_Variations");
            $this->db->where("FVID", $FVID);
            $res = $this->db->get();
            $count = $res->num_rows();

            // $this->db->select("PID");
            // $this->db->from("Feature_Variations");
            // $this->db->where("PID", $PID);
            // $res2 = $this->db->get();
            // $countFeat = $res2->num_rows();

            // $res3 = $this->db->get_where("Product_Master", ["PID" => $PID])->row();
            // $BID = $res3->BID;

            if($count==1){
                
                    $this->db->set($feat);
                    $this->db->where("FVID", $FVID);
                    $this->db->update("Feature_Variations");

                    $this->db->set($col);
                    $this->db->where("CVID", $CVID);
                    return $this->db->update("Color_Variations");

            }
            else{
                    $feat['SID'] = $SID;
                    $this->db->insert("Feature_Variations", $feat);
                    $newFVID = $this->db->insert_id();
                    $col['FVID'] = $newFVID;
                    $this->db->set($col);
                    $this->db->where("CVID", $CVID);
                    return $this->db->update("Color_Variations");
                
            }
        }

        public function GetCVIDByPID($PID){
            $this->db->join("Color_Variations", "Color_Variations.FVID = Feature_Variations.FVID");
            $this->db->where("Feature_Variations.PID", $PID);
            return $this->db->get("Feature_Variations");
        }

        public function InsertMoreDetails($data){
            return $this->db->insert('More_Detail',$data);  
        }

        public function GetMoreDetailsByCVID($CVID){
            return $this->db->get_where("More_Detail", ["CVID" => $CVID]);
        }

        public function UpdateMoreDetails($data, $CVID){
            return $this->db->update("More_Detail",$data,["CVID"=>$CVID]);
        }

        public function GetProductBySID($SID){
            $this->db->select("*");
            $this->db->from("Feature_Variations");
            $this->db->where("SID", $SID);
            $this->db->join("Color_Variations", "Color_Variations.FVID = Feature_Variations.FVID");
            return $this->db->get();
        }

    }
?>