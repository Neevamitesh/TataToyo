<?php
    class ConTran extends CI_Model{
        public function __construct(){
            $this->load->database();
        }
        private function Api($Name,$Param=[]){ 
            $Result;
            try{
                $Param = $this->FilterArray($Param);
                $Q = $this->QM($Param);
                $Result = $this->db->query("CALL {$Name}({$Q})",$Param);
                $Result->next_result();
            }catch(Exception $e){
                echo $e->getMessage();
            }
            return $Result;
        }
        private function QM($Array){
            $Q = [];
            for($i=0;$i<count($Array);$i++){
                $Q[] = "?";
            }
            return implode(",",$Q);
        }
        private function FilterArray($Array=[]){
            foreach ($Array as $key => $value) {
                if(empty($value)){
                    $Array[$key] = "null";
                }
            }
            return $Array;
        }
        public function Consignee($Data){
            return $this->Api("spconsigneemaster",$Data);
        }
        public function Lables($Data){
            return $this->Api("LabelVariables",$Data);
        }
        public function UploadFile($Data){
            return $this->Api("FileUpload",$Data);
        }
        public function GetProduct($Data){
            return $this->Api("ProductMaster",$Data);
        }
    }
?>