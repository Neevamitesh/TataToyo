<?php
    class Test extends CI_Controller{
       function index(){
        $this->load->model("GetProducts");
            $arr= $this->GetProducts->GetAllProducts();
            $res = $this->GetProducts->GetProductDetail(2);
            
            echo "<pre>";
            print_r ($res);
            print_r ($arr);
            echo "</pre>";
            
       }
       function upload(){
            $data = $_FILES['file'];
            $config = array(
                'upload_path' => 'upload/test',
                'allowed_types' => '*'
            );  
            $myfiles = array();
            $this->load->library('upload',$config);
            for($i=0;$i<count($data);$i++){                
                $_FILES['myfile']['name'] = $data['name'][$i];
                $_FILES['myfile']['tmp_name'] = $data['tmp_name'][$i];
                $_FILES['myfile']['size'] = $data['size'][$i];
                $_FILES['myfile']['error'] = $data['error'][$i];
                $_FILES['myfile']['type'] = $data['type'][$i];
                $res = $this->upload->do_upload('myfile');
                print_r($this->upload->display_errors());
                $name = $this->upload->data();
                array_push($myfiles,$name);
            }
            print_r($myfiles[0]);
       }
    }
?>