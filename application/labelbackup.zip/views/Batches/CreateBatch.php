<style>
    .page-title{
        display:none;
    }
</style>
<div class="modal fade" id="view-prn">
    <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="<?= base_url('Consignee/AddVariables');?>" method="post">
                    <input type="hidden" name="Consignee" id="AddVariables-Consignee">
                    <div class="modal-header gradient-forest">
                        <h4 class="modal-title text-white">
                            View PRN
                        </h4>
                    </div>
                    <div class="modal-body">
                        <div id="preview"></div>
                    </div>
                </form>
            </div>
    </div>
</div>

 <div class="card" id="Batch">
    <div class="card-header gradient-forest">
        <div class="card-title text-white">
            Batch Section           
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="card">
                    <div class="card-header gradient-forest">
                        <div class="card-title text-white">
                            Select Product           
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-6 col-12 ">
                                <select id="Consignee" class="form-control form-control-rounded">
                                    <option value="">Select Product</option>
                                    <?php
                                    
                                        foreach ($Products->result() as $key => $row) {
                                            ?>
                                            <option value="<?= $row->id?>"><?= $row->productname?></option>
                                            <?php
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 col-12">
                                <button type="button" id="GetDetails" class="btn btn-gradient-scooter mx-auto waves-effect waves-light btn-round ">Get Detail</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header gradient-forest">
                <div class="card-title text-white">
                    Product Data
                </div>
            </div>
            <div class="card-body">
                <div class="row" id="prd-data">
                </div>
            </div>
        </div>

          <div class="card">
            <div class="card-header gradient-forest">
                <div class="card-title text-white">
                    Consignee Data
                </div>
            </div>
            <div class="card-body">
                <div class="row" id="consignee-data">
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <button type="button" class="btn btn-gradient-scooter" id="getPreview" data-toggle="modal" data-target="#view-prn">View PRN</button>
    </div>
</div>
<script>
var Prd;
    $(function(){
        var img = $("<img class='img-fluid'>");
        $("#Batch #GetDetails").click(function(){
            Prd = $("#Consignee").val();
            $.ajax({
                type: "POST",
                url: base+ "Consignee/GetBatchDetails",
                data:{
                    Prd:Prd
                },
                success:function(data){
                    if(data != false){
                        var Detail = JSON.parse(data);
                        $("#prd-data").html(Detail.Prd);
                        $("#consignee-data").html(Detail.Consignee);
                    }else{
                        // console.log("Error");
                    }
                }
            });
        });
        $("#getPreview").click(function(){
            var PrdTitle = $(".prd-title").map(function(){
                return $(this).val();
            }).get();
            var PrdValue = $(".prd-value").map(function(){
                return $(this).val();
            }).get();

            var ConTitle = $(".consignee-title").map(function(){
                return $(this).val();
            }).get();
            var ConValue = $(".consignee-value").map(function(){
                return $(this).val();
            }).get();
            $("#preview").html("<div class='jumbotron gradient-forest'><h3 class='text-center text-white'>Loading...<h3></div>");
            $.ajax({
                url: base+"Consignee/GetPreview",
                type: "POST",
                data: {
                    Prd: Prd,
                    PrdTitle:PrdTitle,
                    PrdValue:PrdValue,
                    ConTitle:ConTitle,
                    ConValue:ConValue
                },
                success:function(data){
                    var Res = JSON.parse(data);
                    if(Res.Res){
                        img.attr('src',Res.File);
                        $("#preview").html(img);
                    }else{
                        $("#preview").html(Res.File);
                    }
                    console.log(Res);
                }
            });
        });
    });
</script>
