<?php

    class Admin extends CI_Controller{
        
        function __construct(){
            parent::__construct();
            $this->load->library('session');
            $user_id=$this->session->userdata('user_id-PB');
            $role = $this->session->userdata('role-PB');
        }

        public function index(){
            // $this->load->view("NavFoot/navbar");
            $this->load->view("User/index");
            // $this->load->view("NavFoot/footer");
        }

        public function UserValidation(){
            $email=htmlspecialchars($_POST['email']);
            $password=htmlspecialchars($_POST['password']);
            $this->load->model("userValidation");
            $result=$this->userValidation->AdminValidation($email,$password);
            if($result!="error"){
                if($result=="SuperAdmin"){
                    redirect("Home");
                }
                else{
                    redirect("Admin");
                }
            }
            else{
                echo "Error Login";
            }
        }       
        
    }
?>