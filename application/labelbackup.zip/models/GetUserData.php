<?php
    class GetUserData extends CI_Model{
        public function __construct(){
            parent::__construct();
            $this->load->database();
        }
        public function  NavData(){
            return [];
        }

        public function GetStates(){
            return $this->db->get_where("States",["BitStatus"=>1]);
        }
        public function GetCity($State){
            return $this->db->get_where("cities",["BitStatus"=>1,"state_id"=>$State]);
        }
        public function GetType(){
            $Array = explode(",","CONSIGNEEVAR,null,null,null,null,null,null,null,null");
            return $this->Api("P_GET_CD_MASTER_VAL",$Array);
        }
        
        private function Api($Name,$Param=[]){ 
            $Result;
            try{
                $Param = $this->FilterArray($Param);
                $Q = $this->QM($Param);
                $Result = $this->db->query("CALL {$Name}({$Q})",$Param);
                $Result->next_result();
            }catch(Exception $e){
                echo $e->getMessage();
            }
            return $Result;
        }
        private function QM($Array){
            $Q = [];
            for($i=0;$i<count($Array);$i++){
                $Q[] = "?";
            }
            return implode(",",$Q);
        }
        private function FilterArray($Array=[]){
            foreach ($Array as $key => $value) {
                if(empty($value)){
                    $Array[$key] = "null";
                }
            }
            return $Array;
        }
    }
?>