<?php
    class Auth extends CI_Controller{
        private $msg = "Something Went Wrong";
        public function __construct(){
            parent::__construct();
            $this->load->library('session');
            $user_id = $this->session->userdata('user_id-PB');
            if(!empty($user_id)){
                redirect('Home');
            }
            $this->load->model('UserValidation');
        }
        public function Login(){
            (!empty($this->input->post('email')) || !empty($this->input->post('password')))?:redirect("Home/Login"); 
            $email = $this->input->post('email',true);
            $password = $this->input->post('password',true);
            if(empty($email) || empty($password)) {
                $this->session->set_flashdata("Login-PB",$this->msg);
            }
            $res = $this->UserValidation->validateUser($email,$password);
            if($res == "nouser"){
                $this->msg = "User Does Not Exist";
                $this->session->set_flashdata("Login-PB",$this->msg);
                redirect("Home/Login");
            }else if($res == "error"){
                $this->msg = "Password Does Not  Match";
                $this->session->set_flashdata("Login-PB",$this->msg);            
                redirect("Home/Login");
            }else{
                redirect('Home');
            }
        }

        public function OTPLogin(){
            $sessionotp = $this->session->userdata('sessionotp');
            $contact = $this->input->post('contact');
            $userotp = $this->input->post('otp');
            if($sessionotp == $userotp){
                $this->load->model("GetUserData");
                $rawData = $this->GetUserData->isContactExist($contact);
                $userData = $rawData->row();
                $res = $this->UserValidation->validateUser($userData->Email,$userData->Password);
                if($res){
                    redirect('Home');
                }
            }
            else{
                $error = "OTP Does Not  Match";
                $this->load->view("login",['otperror'=>$error]);
            }
        }
    }

?>